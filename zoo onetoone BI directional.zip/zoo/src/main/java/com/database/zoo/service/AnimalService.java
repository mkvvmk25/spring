package com.database.zoo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
// import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Sort;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.database.zoo.model.AnimalCage;
import com.database.zoo.repositary.AnimalCageRepositary;

@Service
public class AnimalService {
    @Autowired   // its gets intialised
    private AnimalCageRepositary animalRepositary;

    public AnimalCage saveAnimal(AnimalCage animal)
    {
        return animalRepositary.save(animal);
    }


    public List<AnimalCage> saveAnimalList(List<AnimalCage> animal)
    {
        return animalRepositary.saveAll(animal);
    }

    public AnimalCage  getAnimal(int id)
    {
        return animalRepositary.findById(id).orElse(null);
    }

    public List<AnimalCage> zooAnimals()
    {
        return animalRepositary.findAll();
    }

    public List<AnimalCage> getAnimals()
    {
        
        return animalRepositary.findAll();
    }

    public List<AnimalCage> getAnimalNames(String name)
    {
        // return animalRepositary.findByName(name);
        return null;
    }


    public void deleteAnimal(int id)
    {
        animalRepositary.deleteById(id);
    }

    public List<AnimalCage> pagenate()
    {
        return animalRepositary.findAll(PageRequest.of(0, 2,Sort.by(Direction.DESC,"name"))).getContent();
    }


    public List<AnimalCage> pageNation(int pageNo, int siz)
    {
        Page<AnimalCage> pg = animalRepositary.findAll( PageRequest.of(pageNo, siz) );
        return pg.getContent();
    }

    public List<AnimalCage> pageNationSort(int pageNo, int siz, String name )
    {
        Page<AnimalCage> pg = animalRepositary.findAll( 
                    PageRequest.of(
                        pageNo, 
                        siz,
                        Sort.by(Direction.DESC, name)) );
        return pg.getContent();
    }
}

