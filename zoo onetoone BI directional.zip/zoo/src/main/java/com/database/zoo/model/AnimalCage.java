package com.database.zoo.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
// import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor 
@AllArgsConstructor
public class AnimalCage
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cageNo;
    private String name;
    private int nos;

    @OneToOne(mappedBy = "animalCage", cascade = CascadeType.ALL) // if not try REMOVE
    @JsonManagedReference // for primary 
    private AnimalDescription animalDescription;


    // @OneToMany(mappedBy = "animalCage", cascade = CascadeType.ALL)
    // private List<AnimalDescription> animalDescriptions;
}
