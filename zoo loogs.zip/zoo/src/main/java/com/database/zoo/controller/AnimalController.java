package com.database.zoo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
// import org.hibernate.engine.jdbc.env.internal.LobCreationLogging_.logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.database.zoo.model.AnimalCage;
import com.database.zoo.model.AnimalDescription;
import com.database.zoo.repositary.AnimalDescriptionRepsositary;
import com.database.zoo.service.AnimalService;

// import ch.qos.logback.classic.Logger;




@RestController
public class AnimalController {
    
    public final Logger logger = LoggerFactory.getLogger(AnimalController.class);

    private AnimalService animalService;

    @Autowired
    private AnimalDescriptionRepsositary animalDescriptionRepsositary;


    @GetMapping("/animals")
    public List<AnimalCage> getMethodName() {
        logger.error("error **");
        logger.debug("debug **");
        logger.info("info **");
        logger.trace("trace **");
        logger.warn("warn **");
        return animalService.zooAnimals();
    }

    public AnimalController(AnimalService animalService)
    {
        this.animalService = animalService;
    }

    @ResponseStatus(value=HttpStatus.CREATED)
    @PostMapping("/post")
    public String postMethodName(@RequestBody AnimalCage animal) {
        animalService.saveAnimal(animal);
        return "saved";
    }

    // @ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
    @PostMapping("/postdes")
    public String postMethosdName(@RequestBody AnimalDescription animal) {
        animalDescriptionRepsositary.save(animal);
        return "saved";
    }

    @PostMapping("/postlist")
    public String postMethodName(@RequestBody List<AnimalCage> animal) {
        animalService.saveAnimalList(animal);
        return "saved";
    }

    @GetMapping("/animal/{id}")
    public AnimalCage getMethodName(@PathVariable("id") int a) {
        return animalService.getAnimal(a);
    }

    @PutMapping("/animal/nos/{id}")
    
    public ResponseEntity<String> putMethodName(@PathVariable int id, 
                            @RequestBody AnimalCage updateAnimal) {
        AnimalCage existAnimal = animalService.getAnimal(id);
        if(existAnimal != null)
        {
            existAnimal.setName(updateAnimal.getName());
            existAnimal.setNos(   updateAnimal.getNos() );
            animalService.saveAnimal(existAnimal);
        }
        else 
        {
            return new ResponseEntity<>("data not found ",HttpStatus.NOT_ACCEPTABLE);
        }
        return new ResponseEntity<>("updated ",HttpStatus.OK);
    }


    @DeleteMapping("/animal/{id}")
    public String animaldel(@PathVariable("id") int id)
    {
        AnimalCage existAnimal = animalService.getAnimal(id);
        if(existAnimal != null)
        {
            animalService.deleteAnimal(id);
            return "deleted";
        }
        return "deleted";
    } 
    
   

    @GetMapping("/anipage/{pn}/{sz}")
    public List<AnimalCage> getMethodNamase(@PathVariable("pn") int pn,
                                        @PathVariable("sz") int sz ) 
    {
        return animalService.pageNation(pn, sz);
    }

    @GetMapping("/anipage/{pn}/{sz}/{name}")
    // @GetMapping("/anipage/page")
    public List<AnimalCage> getMethodNamase(@PathVariable("pn") int pn,
                                        @PathVariable("sz") int sz ,
                                        @PathVariable("sz") String name ) 
    {
        return animalService.pageNationSort(pn, sz,name);
    }
    
    
    // java databe

}
