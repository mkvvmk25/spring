package com.database.zoo.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.database.zoo.model.AnimalDescription;

public interface AnimalDescriptionRepsositary extends JpaRepository<AnimalDescription,Integer> 
{
    
}
