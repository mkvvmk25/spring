package com.database.zoo.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.database.zoo.model.Animal;

@Repository
public interface AnimalRepositary extends JpaRepository<Animal, Integer> {
    
}
