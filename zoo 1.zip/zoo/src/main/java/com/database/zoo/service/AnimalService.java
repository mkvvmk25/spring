package com.database.zoo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.database.zoo.model.Animal;
import com.database.zoo.repositary.AnimalRepositary;

@Service
public class AnimalService {
    @Autowired   // its gets intialised
    private AnimalRepositary animalRepositary;

    public Animal saveAnimal(Animal animal)
    {
        return animalRepositary.save(animal);
    }

    public Animal  getAnimal(int id)
    {
        return animalRepositary.findById(id).orElse(null);
    }

    public List<Animal> getAnimals()
    {
        return animalRepositary.findAll();
    }

    public void deleteAnimal(int id)
    {
        animalRepositary.deleteById(id);
    }
}

