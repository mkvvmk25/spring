package com.database.zoo.controller;

import org.springframework.web.bind.annotation.RestController;

import com.database.zoo.model.Animal;
import com.database.zoo.service.AnimalService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PutMapping;




@RestController
public class AnimalController {
    
    private AnimalService animalService;


    public AnimalController(AnimalService animalService)
    {
        this.animalService = animalService;
    }

    @PostMapping("/post")
    public String postMethodName(@RequestBody Animal animal) {
        animalService.saveAnimal(animal);
        return "saved";
    }

    @GetMapping("/animal/{id}")
    public Animal getMethodName(@PathVariable("id") int a) {
        return animalService.getAnimal(a);
    }
    @GetMapping("/animals")
    public List<Animal> getallani() {
        return animalService.getAnimals();
    }

    @PutMapping("/animal/nos/{id}")
    public String putMethodName(@PathVariable int id, 
                            @RequestBody Animal updateAnimal) {
        Animal existAnimal = animalService.getAnimal(id);
        if(existAnimal != null)
        {
            existAnimal.setName(updateAnimal.getName());
            existAnimal.setNos(   updateAnimal.getNos() );
            animalService.saveAnimal(existAnimal);
        }
        else 
        {
            return "no data found";
        }
        return "updated";
    }


    @DeleteMapping("/animal/{id}")
    public String animaldel(@PathVariable("id") int id)
    {
        Animal existAnimal = animalService.getAnimal(id);
        if(existAnimal != null)
        {
            animalService.deleteAnimal(id);
            return "deleted";
        }
        return "deleted";
    } 
    
    
}
