package com.database.zoo.aspectclass;



import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

@Aspect 
@Configuration
public class AspectConfig {
    

     Logger logger=LoggerFactory.getLogger("servicelogs");

    // Executes before the method
    // first * all class
    //       * all the methods 
    //       (..)  0 parameters 
    @Before(value="execution(* com.database.zoo.controller.*.*(..)  ) ")
    public void beforeAdvice (JoinPoint joinpoint)
    {	
        logger.info("Inside Befroe Advice " + joinpoint.getSignature().getName());
    }
    //Executes after the method
    @After(value="execution(* com.database.zoo.controller.*.*(..)) ")
    public void afterAdvice (JoinPoint joinpoint)
    {	logger.info("Inside After Advice");
    }
    // //Executes before the method along with the parameter
    @Before(value="execution(* com.database.zoo.controller.*.*(..)) and args(object) ")
    public void beforeAdviceWith1Param (JoinPoint joinpoint, Object object)
    {	
        logger.info("Inside Befroe Advice with parameter"+object);
    }

    @Before(value="execution(* com.database.zoo.controller.*.*(..))")
    public void beforeAdviceWith1Param (JoinPoint joinpoint)
    {	Object args[]=joinpoint.getArgs();
        for(Object arg:args)
         System.out.println(arg.toString());
        logger.info("Inside Befroe Advice with parameter"+args);
    }

    //Executes afterReturning the value to called the method(which performs prior to After method)
    // @AfterReturning(value="execution(* com.example.onetomanyuniauthor.controller.AuthorController.getAuthors(..)   ) ",returning = "")
    // public void afterReturningAdvice (JoinPoint joinpoint)
    // {	
    //     logger.info("Inside AfterReturning Advice");
    // }

}
