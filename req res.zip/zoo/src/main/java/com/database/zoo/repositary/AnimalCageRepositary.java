package com.database.zoo.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.database.zoo.model.AnimalCage;

@Repository
public interface AnimalCageRepositary extends JpaRepository<AnimalCage, Integer> 
{
   
}
